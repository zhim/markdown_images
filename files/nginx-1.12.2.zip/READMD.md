# 将java程序注册为windows服务

## command

service.exe install
service.exe uninstall
service.exe start
service.exe stop 或者 net start eureka
service.exe restart 或者 net start eureka
service.exe status 或者 net start eureka

## the dir logs must create


## service-config

```
<service>
  <id>eureka</id>
  <name>eureka</name>
  <description>eureka</description>
  <logpath>%BASE%\logs</logpath>
  <log mode="roll-by-size">
    <sizeThreshold>10240</sizeThreshold>
    <keepFiles>8</keepFiles>
  </log>
  <executable>java.exe</executable>
  <arguments>-jar "%BASE%\abc.eureka.service-0.0.1-SNAPSHOT.jar"</arguments>
  <!--
  <arguments>-jar "%BASE%\..\target\abc.eureka.service-0.0.1-SNAPSHOT.jar"</arguments>
  -->
</service>
```

## 原理

https://github.com/kohsuke/winsw